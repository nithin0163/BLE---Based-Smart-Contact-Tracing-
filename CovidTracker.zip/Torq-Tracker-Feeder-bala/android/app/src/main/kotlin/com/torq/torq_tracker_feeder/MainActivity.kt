package com.torq.torq_tracker_feeder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
